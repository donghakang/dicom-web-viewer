import CornerstoneViewport from './CornerstoneViewport/CornerstoneViewport.js';

describe('CornerstoneViewport', () => {
  it('is truthy', () => {
    expect(CornerstoneViewport).toBeTruthy();
  });
});
